
bash scripts/01-policy-gradient-cartpole.sh
bash scripts/02-policy-gradient-pendulum.sh
bash scripts/03-policy-gradient-lunar-lander.sh
bash scripts/04-policy-gradient-half-cheetah.sh
bash scripts/05-pg-gae-hopper.sh
bash scripts/06-actor-critic-cartpole.sh
bash scripts/07-actor-critic-difficult.sh
bash scripts/08-dyna.sh
bash scripts/09-multi-step-pg.sh
bash scripts/10-ac-ppo-clip.sh
bash scripts/11-parallelized-data-collection.sh
