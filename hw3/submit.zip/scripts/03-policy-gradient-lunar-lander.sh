
# Experiment 3

python run_hw3.py env_name=LunarLanderContinuous-v2 ep_len=1000 discount=0.99 reward_to_go=true nn_baseline=true batch_size=40000 learning_rate=0.005 exp_name=q3_b40000_r0.005 rl_alg=reinforce


