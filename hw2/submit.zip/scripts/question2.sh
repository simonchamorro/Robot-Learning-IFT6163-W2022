
# Question 2

python run_hw2_mb.py exp_name=q2_obstacles_singleiteration env_name=obstacles-ift6163-v0 num_agent_train_steps_per_iter=20 batch_size_initial=5000 batch_size=1000 mpc_horizon=10 video_log_freq=-1


