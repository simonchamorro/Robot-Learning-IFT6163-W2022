
bash scripts/01-dqn.sh
bash scripts/02-ddpg.sh
bash scripts/03-td3.sh

